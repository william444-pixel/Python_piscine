from .mazegen import MazeGenerator, interactive_menu

__all__ = ["MazeGenerator", "interactive_menu"]
